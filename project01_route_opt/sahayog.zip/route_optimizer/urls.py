"""
URL configuration for the route optimizer app.
"""
from django.urls import path
from . import views

app_name = 'route_optimizer'

urlpatterns = [
    # Main views
    path('', views.index, name='index'),
    path('locations/', views.locations, name='locations'),
    path('vehicles/', views.vehicles, name='vehicles'),
    path('optimize/', views.optimize_route, name='optimize_route'),
    path('routes/', views.routes_list, name='routes_list'),
    path('route/<int:route_id>/', views.route_details, name='route_details'),
    path('history/', views.optimization_history, name='optimization_history'),
    
    # Management views
    path('add-location/', views.add_location, name='add_location'),
    path('add-vehicle/', views.add_vehicle, name='add_vehicle'),
    
    # API endpoints
    path('api/locations/', views.api_locations, name='api_locations'),
    path('api/vehicles/', views.api_vehicles, name='api_vehicles'),
    path('api/route/<int:route_id>/stats/', views.api_route_statistics, name='api_route_statistics'),
    path('api/history/', views.api_optimization_history, name='api_optimization_history'),
    path('api/recommend/', views.api_recommend_route, name='api_recommend_route'),
]
