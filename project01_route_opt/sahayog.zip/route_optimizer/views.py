"""
Views for the route optimization web interface.
"""
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Q
import json
from .models import Location, Vehicle, OptimizedRoute, RouteLocation, RouteOptimizationSession
from .optimization_engine import RouteOptimizationService


def index(request):
    """Main dashboard view."""
    # Get recent routes
    recent_routes = OptimizedRoute.objects.all().order_by('-created_at')[:5]
    
    # Get statistics
    total_routes = OptimizedRoute.objects.count()
    total_locations = Location.objects.filter(is_active=True).count()
    total_vehicles = Vehicle.objects.filter(is_available=True).count()
    
    # Get optimization history
    optimization_service = RouteOptimizationService()
    history_result = optimization_service.get_optimization_history()
    optimization_history = history_result.get('data', []) if history_result['success'] else []
    
    context = {
        'recent_routes': recent_routes,
        'total_routes': total_routes,
        'total_locations': total_locations,
        'total_vehicles': total_vehicles,
        'optimization_history': optimization_history[:5],
    }
    
    return render(request, 'route_optimizer/index.html', context)


def locations(request):
    """Locations management view."""
    search_query = request.GET.get('search', '')
    location_type = request.GET.get('type', '')
    
    locations_list = Location.objects.filter(is_active=True)
    
    if search_query:
        locations_list = locations_list.filter(
            Q(name__icontains=search_query) | 
            Q(address__icontains=search_query)
        )
    
    if location_type:
        locations_list = locations_list.filter(location_type=location_type)
    
    # Pagination
    paginator = Paginator(locations_list, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search_query': search_query,
        'location_type': location_type,
        'location_types': Location._meta.get_field('location_type').choices,
    }
    
    return render(request, 'route_optimizer/locations.html', context)


def vehicles(request):
    """Vehicles management view."""
    search_query = request.GET.get('search', '')
    vehicle_type = request.GET.get('type', '')
    
    vehicles_list = Vehicle.objects.all()
    
    if search_query:
        vehicles_list = vehicles_list.filter(
            Q(name__icontains=search_query) | 
            Q(vehicle_type__icontains=search_query)
        )
    
    if vehicle_type:
        vehicles_list = vehicles_list.filter(vehicle_type=vehicle_type)
    
    # Pagination
    paginator = Paginator(vehicles_list, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search_query': search_query,
        'vehicle_type': vehicle_type,
        'vehicle_types': Vehicle._meta.get_field('vehicle_type').choices,
    }
    
    return render(request, 'route_optimizer/vehicles.html', context)


def optimize_route(request):
    """Route optimization form view."""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            location_ids = data.get('location_ids', [])
            vehicle_id = data.get('vehicle_id')
            route_name = data.get('route_name', '')
            depot_location_id = data.get('depot_location_id')
            
            if not location_ids or not vehicle_id or not route_name:
                return JsonResponse({
                    'success': False,
                    'error': 'Missing required parameters'
                })
            
            # Create optimized route
            optimization_service = RouteOptimizationService()
            result = optimization_service.create_optimized_route(
                location_ids=location_ids,
                vehicle_id=vehicle_id,
                route_name=route_name,
                depot_location_id=depot_location_id
            )
            
            if result['success']:
                messages.success(request, f'Route "{route_name}" optimized successfully!')
                return JsonResponse({
                    'success': True,
                    'route_id': result['route_id'],
                    'message': 'Route optimized successfully',
                    'total_distance': result.get('total_distance'),
                    'total_time': result.get('total_time'),
                    'estimated_fuel_consumption': result.get('estimated_fuel_consumption'),
                    'route_path_coords': result.get('route_path_coords', []),
                    'route_segments': result.get('route_segments', []),
                    'start': result.get('route_path_coords', [None])[0] if result.get('route_path_coords') else None,
                    'end': result.get('route_path_coords', [None])[-1] if result.get('route_path_coords') else None
                })
            else:
                return JsonResponse({
                    'success': False,
                    'error': result['error']
                })
                
        except json.JSONDecodeError:
            return JsonResponse({
                'success': False,
                'error': 'Invalid JSON data'
            })
        except Exception as e:
            return JsonResponse({
                'success': False,
                'error': str(e)
            })
    
    # GET request - show form
    locations_list = Location.objects.filter(is_active=True)
    vehicles_list = Vehicle.objects.filter(is_available=True)
    
    context = {
        'locations': locations_list,
        'vehicles': vehicles_list,
    }
    
    return render(request, 'route_optimizer/optimize_route.html', context)


def route_details(request, route_id):
    """Route details view."""
    route = get_object_or_404(OptimizedRoute, id=route_id)
    route_locations = RouteLocation.objects.filter(route=route).order_by('visit_order')
    
    # Get route statistics
    optimization_service = RouteOptimizationService()
    stats_result = optimization_service.get_route_statistics(route_id)
    route_stats = stats_result.get('data', {}) if stats_result['success'] else {}
    
    context = {
        'route': route,
        'route_locations': route_locations,
        'route_stats': route_stats,
    }
    
    return render(request, 'route_optimizer/route_details.html', context)


def routes_list(request):
    """Routes list view."""
    search_query = request.GET.get('search', '')
    status_filter = request.GET.get('status', '')
    
    routes_list = OptimizedRoute.objects.all()
    
    if search_query:
        routes_list = routes_list.filter(
            Q(route_name__icontains=search_query) | 
            Q(vehicle__name__icontains=search_query)
        )
    
    if status_filter:
        routes_list = routes_list.filter(status=status_filter)
    
    # Pagination
    paginator = Paginator(routes_list, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search_query': search_query,
        'status_filter': status_filter,
        'status_choices': OptimizedRoute._meta.get_field('status').choices,
    }
    
    return render(request, 'route_optimizer/routes_list.html', context)


def optimization_history(request):
    """Optimization history view."""
    sessions_list = RouteOptimizationSession.objects.all().order_by('-created_at')
    
    # Pagination
    paginator = Paginator(sessions_list, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
    }
    
    return render(request, 'route_optimizer/optimization_history.html', context)


# API endpoints for AJAX requests
@csrf_exempt
def api_locations(request):
    """API endpoint to get locations for route optimization."""
    if request.method == 'GET':
        locations_list = Location.objects.filter(is_active=True).values(
            'id', 'name', 'address', 'location_type', 'priority', 'estimated_waste_volume'
        )
        return JsonResponse({'success': True, 'data': list(locations_list)})
    
    return JsonResponse({'success': False, 'error': 'Method not allowed'})


@csrf_exempt
def api_vehicles(request):
    """API endpoint to get vehicles for route optimization."""
    if request.method == 'GET':
        vehicles_list = Vehicle.objects.filter(is_available=True).values(
            'id', 'name', 'vehicle_type', 'capacity', 'fuel_efficiency'
        )
        return JsonResponse({'success': True, 'data': list(vehicles_list)})
    
    return JsonResponse({'success': False, 'error': 'Method not allowed'})


@csrf_exempt
def api_route_statistics(request, route_id):
    """API endpoint to get route statistics."""
    if request.method == 'GET':
        optimization_service = RouteOptimizationService()
        result = optimization_service.get_route_statistics(route_id)
        return JsonResponse(result)
    
    return JsonResponse({'success': False, 'error': 'Method not allowed'})


@csrf_exempt
def api_optimization_history(request):
    """API endpoint to get optimization history."""
    if request.method == 'GET':
        optimization_service = RouteOptimizationService()
        result = optimization_service.get_optimization_history()
        return JsonResponse(result)
    
    return JsonResponse({'success': False, 'error': 'Method not allowed'})


@csrf_exempt
def api_recommend_route(request):
    """Given selected locations and optional vehicle/depot, return recommended path preview."""
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            location_ids = data.get('location_ids', [])
            vehicle_id = data.get('vehicle_id')
            depot_location_id = data.get('depot_location_id')

            if not location_ids:
                return JsonResponse({'success': False, 'error': 'No locations provided'})

            # If no vehicle yet, fake a lightweight capacity using the first available vehicle or default params
            vehicle = None
            if vehicle_id:
                try:
                    vehicle = Vehicle.objects.get(id=vehicle_id)
                except Vehicle.DoesNotExist:
                    vehicle = None
            if not vehicle:
                # Create an in-memory lightweight vehicle substitute
                class _V: pass
                vehicle = _V()
                vehicle.capacity = 10_000

            # Optimize without saving
            optimizer = RouteOptimizationService().optimizer
            locations = list(Location.objects.filter(id__in=location_ids, is_active=True))
            if not locations:
                return JsonResponse({'success': False, 'error': 'Invalid locations'})

            depot_index = 0
            if depot_location_id:
                try:
                    depot_index = next(i for i, loc in enumerate(locations) if loc.id == depot_location_id)
                except StopIteration:
                    depot_index = 0

            # Use short solve for preview
            result = optimizer.optimize_route(locations, vehicle, depot_index, solve_seconds=5)
            if not result.get('success'):
                return JsonResponse(result)

            return JsonResponse({
                'success': True,
                'route_path_coords': result.get('route_path_coords', []),
                'route_segments': result.get('route_segments', []),
                'total_distance': result.get('total_distance'),
                'total_time': result.get('total_time'),
                'estimated_fuel_consumption': result.get('estimated_fuel_consumption'),
                'start': result.get('route_path_coords', [None])[0] if result.get('route_path_coords') else None,
                'end': result.get('route_path_coords', [None])[-1] if result.get('route_path_coords') else None,
            })
        except Exception as e:
            return JsonResponse({'success': False, 'error': str(e)})

    return JsonResponse({'success': False, 'error': 'Method not allowed'})


# Management views
def add_location(request):
    """Add new location view."""
    if request.method == 'POST':
        try:
            name = request.POST.get('name')
            address = request.POST.get('address')
            latitude = request.POST.get('latitude')
            longitude = request.POST.get('longitude')
            location_type = request.POST.get('location_type')
            priority = request.POST.get('priority')
            estimated_waste_volume = request.POST.get('estimated_waste_volume', 0)
            
            if not all([name, address, latitude, longitude, location_type]):
                messages.error(request, 'Please fill all required fields')
                return redirect('add_location')
            
            Location.objects.create(
                name=name,
                address=address,
                latitude=latitude,
                longitude=longitude,
                location_type=location_type,
                priority=priority,
                estimated_waste_volume=estimated_waste_volume
            )
            
            messages.success(request, 'Location added successfully!')
            return redirect('locations')
            
        except Exception as e:
            messages.error(request, f'Error adding location: {str(e)}')
    
    context = {
        'location_types': Location._meta.get_field('location_type').choices,
        'priority_choices': Location._meta.get_field('priority').choices,
    }
    
    return render(request, 'route_optimizer/add_location.html', context)


def add_vehicle(request):
    """Add new vehicle view."""
    if request.method == 'POST':
        try:
            name = request.POST.get('name')
            vehicle_type = request.POST.get('vehicle_type')
            capacity = request.POST.get('capacity')
            fuel_efficiency = request.POST.get('fuel_efficiency')
            latitude = request.POST.get('latitude')
            longitude = request.POST.get('longitude')
            
            if not all([name, vehicle_type, capacity, fuel_efficiency]):
                messages.error(request, 'Please fill all required fields')
                return redirect('add_vehicle')
            
            Vehicle.objects.create(
                name=name,
                vehicle_type=vehicle_type,
                capacity=capacity,
                fuel_efficiency=fuel_efficiency,
                current_latitude=latitude if latitude else None,
                current_longitude=longitude if longitude else None
            )
            
            messages.success(request, 'Vehicle added successfully!')
            return redirect('vehicles')
            
        except Exception as e:
            messages.error(request, f'Error adding vehicle: {str(e)}')
    
    context = {
        'vehicle_types': Vehicle._meta.get_field('vehicle_type').choices,
    }
    
    return render(request, 'route_optimizer/add_vehicle.html', context)
